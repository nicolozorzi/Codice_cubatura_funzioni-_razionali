
function [m,omega]=mommod_1(n)

global Z1 Z2
syms x p omega;

omega=prod((1+x*Z1).^Z2);
p=1./omega;
p=matlabFunction(p);
m(1)=integral(p,-1,1);

for i=1:2*n-1
    p=chebyshevT(i, x).*2.^(1-i)./omega; 
    p=matlabFunction(p); 
    m(i+1)=integral(p,-1,1);
end
omega=matlabFunction(omega);

