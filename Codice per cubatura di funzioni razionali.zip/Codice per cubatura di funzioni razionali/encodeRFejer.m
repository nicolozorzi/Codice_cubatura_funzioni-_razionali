
function sgl=encodeRFejer(numdeg,denmat)

%--------------------------------------------------------------------------


% Coding in "block1" the part relative to the zeros and their multiplicity.

block1=[];
L=size(denmat,1);
for k=1:L
    block1L=repmat(denmat(k,1),1,denmat(k,2));
    block1=[block1 block1L];
end

% Coding in "block2" the part relative to degree of precision.
if numdeg > 0
    block2=repmat(inf,1,numdeg);
else
    block2=[];
end

% Assembling output "sgl".
sgl=[block1 block2];
[x,Err,Rel,y]=rfejer(sgl);



