function [err_rfejer,tempo_rfejer]=analisi_rfejer

clear

%%%%%%%%%%%%%%%%%%% polo semplice %%%%%%%%%%%%%%%%%%%%%%%
%poli=1+10^(-1); integrale=-3.55068710468108;
%poli=1+10^(-2); integrale=-5.75235468583048;
%poli=1+10^(-5); integrale=-12.6491063671656;
%poli=1+10^(-7); integrale=-17.2542656656102;
%poli=1+10^(-10); integrale=-24.1620208347273;
%molt=1; f=@(x) 1./sin(x-poli);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%% poli reali doppi %%%%%%%%%%%%%%%%%%%%%%%
%poli=1+10^(-1); integrale=-19.4097108578298;
%poli=1+10^(-2); integrale=-199.363279589867;
%poli=1+10^(-5); integrale=-199999.357912779;
%molt=2; f=@(x) 1./(cos(x-poli)-1)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%% poli complessi coniugati %%%%%%%%%%%%%%%%%%%%%%%
%poli=[j*10^(-1) -j*10^(-1)]; integrale=28.5961936871968; molt=[1 1]; f=@(x) cos(x)./(x.^2+10^(-1).^2);
%poli=[j*10^(-2) -j*10^(-2)]; integrale=311.202161124091; molt=[1 1]; f=@(x) cos(x)./(x.^2+10^(-2).^2);
%poli=[j*10^(-5) -j*10^(-5)]; integrale=314156.292603935; molt=[1 1]; f=@(x) cos(x)./(x.^2+10^(-5).^2);
%poli=[j*10^(-7) -j*10^(-7)]; integrale=3.14159235631273*10^7; molt=[1 1]; f=@(x) cos(x)./(x.^2+10^(-7).^2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%% poli misti %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%poli=[j*10^(-1) -j*10^(-1) 1+10^(-1)]; integrale=-27.7061469332098; molt=[1 1 1]; f=@(x) cos(x)./((x.^2+10^(-1).^2).*(x-1-10^(-1)));
%poli=[j*10^(-2) -j*10^(-2) 1+10^(-2)]; integrale=-311.738125873081; molt=[1 1 1]; f=@(x) cos(x)./((x.^2+10^(-2).^2).*(x-1-10^(-2)));
%poli=[j*10^(-5) -j*10^(-5) 1+10^(-5)]; integrale=-314160.638833809; molt=[1 1 1]; f=@(x) cos(x)./((x.^2+10^(-5).^2).*(x-1-10^(-5)));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 

rtoll=10^(-6)

i=1;
k=1;
tic;
deg=0;
sgl= encodeRFejer(deg,[[poli]' [molt]']);
xw=rfejer(sgl); int_rfejer=f(xw(1,:))*xw(2,:)';
tempo_rfejer(i)=toc;
err_rfejer(i)=abs((int_rfejer-integrale)/integrale);

while( err_rfejer(i)>rtoll & i<60)
    i=i+1;
    deg=deg+k;
    sgl= encodeRFejer(deg,[[poli]' [molt]']);
    xw=rfejer(sgl); int_rfejer=f(xw(1,:))*xw(2,:)';
    tempo_rfejer(i)=toc;
    err_rfejer(i)=abs((int_rfejer-integrale)/integrale);
end

fprintf('\n errore relativo rfejer: %1.5e ', err_rfejer(end))
fprintf('\n tempo medio rfejer: %3.5f ', mean(tempo_rfejer(1:end)))
fprintf('\n n. nodi rfejer: %1i ', length(xw))

