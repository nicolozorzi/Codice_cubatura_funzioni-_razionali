function [err_gr_discretizzato,tempo_gr_discretizzato]=analisi_gr_dis

clear

%%%%%%%%%%%%%%%%%%% polo semplice %%%%%%%%%%%%%%%%%%%%%%%
%poli=1+10^(-1); integrale=-3.55068710468108;
%poli=1+10^(-2); integrale=-5.75235468583048;
%poli=1+10^(-5); integrale=-12.6491063671656;
%poli=1+10^(-7); integrale=-17.2542656656102;
%poli=1+10^(-10); integrale=-24.1620208347273;
%molt=1; f=@(x) 1./sin(x-poli);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%% poli reali doppi %%%%%%%%%%%%%%%%%%%%%%%
%poli=1+10^(-1); integrale=-19.4097108578298;
%poli=1+10^(-2); integrale=-199.363279589867;
%poli=1+10^(-5); integrale=-199999.357912779;
%poli=1+10^(-7); integrale=-1.99999993579074*10^7;
%molt=2; f=@(x) 1./(cos(x-poli)-1);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%% poli complessi coniugati %%%%%%%%%%%%%%%%%%%%%%%
%poli=[j*10^(-1) -j*10^(-1)]; integrale=28.5961936871968; molt=[1 1]; f=@(x) cos(x)./(x.^2+10^(-1).^2);
%poli=[j*10^(-2) -j*10^(-2)]; integrale=311.202161124091; molt=[1 1]; f=@(x) cos(x)./(x.^2+10^(-2).^2);
%poli=[1j*10^(-3) -1j*10^(-3)]; integrale=3138.62145321803; molt=[1 1]; f=@(x) cos(x)./(x.^2+10^(-3).^2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%% poli misti %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%poli=[j*10^(-1) -j*10^(-1) 1+10^(-1)]; integrale=-27.7061469332098; molt=[1 1 1]; f=@(x) cos(x)./((x.^2+10^(-1).^2).*(x-1-10^(-1)));
%poli=[j*10^(-2) -j*10^(-2) 1+10^(-2)]; integrale=-311.738125873081; molt=[1 1 1]; f=@(x) cos(x)./((x.^2+10^(-2).^2).*(x-1-10^(-2)));
%poli=[j*10^(-3) -j*10^(-3) 1+10^(-3)]; integrale=-3140.46732063763; molt=[1 1 1]; f=@(x) cos(x)./((x.^2+10^(-3).^2).*(x-1-10^(-3)));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

rtoll=10^(-12);

i=1;
k=1; n=i+k;
[abmod,Ncap,kount,xw,tempo, int_gr_discretizzato]=discret_GW(n,f,poli,molt);
tempo_gr_discretizzato(i)=tempo;
err_gr_discretizzato(i)=abs((int_gr_discretizzato-integrale)/integrale);

while(err_gr_discretizzato(i)>rtoll & n<30)
    i=i+1;
    n=i+k;
    [abmod,Ncap,kount,xw,tempo, int_gr_discretizzato]=discret_GW(n,f,poli,molt);
    tempo_gr_discretizzato(i)=tempo;
    err_gr_discretizzato(i)=abs((int_gr_discretizzato-integrale)/integrale);
end


fprintf('\n errore relativo gauss razionele discretizzato: %1.5e ', err_gr_discretizzato(end))
fprintf('\n tempo medio gauss razionele discretizzato: %3.5f ', mean(tempo_gr_discretizzato(1:end)))
fprintf('\n n. nodi gauss razionele discretizzato: %3i ', length(xw))
