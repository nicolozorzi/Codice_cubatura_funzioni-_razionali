
function [gr,err,T,xw1]=cheb_mod(integrale,f,poli,molt,n)

warning off

tic
if sum(molt)>2*n
    fprintf('n troppo basso\n'), gr=inf;
    xw1=NaN; err=NaN; T=NaN;
else
    poli=-1./poli;
    clear Z1 Z2
    global Z1 Z2
    Z1=poli'; Z2=molt';
    abm=r_jacobi(2*n-1,-1/2);
    [mom,omega]=mommod(n);
    [ab,normsq]=chebyshev(n,mom,abm); 
    xw1=gauss(n,ab); 
    xw1(:,2)=xw1(:,2).*omega(xw1(:,1)); 
    gr=f(xw1(:,1))'*xw1(:,2); 
    T=toc; 
    err=abs((integrale-gr)/integrale);
end

